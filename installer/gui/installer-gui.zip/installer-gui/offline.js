﻿{
	"version": 1760216234,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/title-sheet0.png",
		"images/bgtext-sheet0.png",
		"images/moldura-sheet0.png",
		"media/whatislove.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"video.ogv"
	]
}